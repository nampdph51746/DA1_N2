<?php
session_start();
require_once __DIR__ . "/routes/route.php";
