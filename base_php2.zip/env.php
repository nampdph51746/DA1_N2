<?php
//Đường dẫn
define("APP_URL", "http://localhost/base_php2/");
define("ROOT_DIR", __DIR__);
//Database
define('HOST', "localhost");
define('DBNAME', "");
define('USERNAME', "root");
define('PASSWORD', "");
define('PORT', "3306");
