<?php

$router->get('/admin', function () {
    return "View Admin";
});
