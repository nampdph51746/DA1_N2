<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>404 Not found</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container">

        <div class="text-center mt-5">
            <h1>404 File Not Found!</h1>
            <h2>Đường dẫn bạn đang dùng không tồn tại</h2>
        </div>

    </div>
</body>

</html>
