<?php

use App\Models\Post;

$router->get('/', function () {
    return "Phần dàn cho khách";
});
